# mini-project-groupt-1
-------------------------------------------------------------------------------------------------------------------------------------
Anggota kelompok - 1 :

- (Leader) Bagas Restya Ermawan

- Alda Mevia

- Bagas Nurfauzi Hidayatullah

- Latief Fatkhur Rahman

- Maulana Arya Yoga Juliansyah
-------------------------------------------------------------------------------------------------------------------------------------
Deskripsi Usaha : Hotgengs Sambal adalah sebuah resep sambal restoran asal Bandung,yaitu Babakaran yang berdiri sejak
2015 Hotgengs Sambal mulai digemari,karena cita rasanya yang pedas.

Link Sosial Media :  https://www.instagram.com/hotgengs 

Link Desain Web (UI) : https://www.figma.com/file/5xDKe5On3mDtPNWvsP4UPh/UKM?type=design&node-id=0%3A1&mode=design&t=d5zaPoMxozgAAYed-1

